<?php

/**
 * Theme Name: Limeaid
 */


return array(
	'colors' => array(
		'#bb3a88',
		'green',
		'red',
		'black',
		'yellow',
		'orange',
		'green',
		'green',
		'green',
		'green',
		'green',
		'green',
		'green',
		'green',
	),
);